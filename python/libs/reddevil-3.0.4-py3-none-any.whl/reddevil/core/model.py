# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2021

import logging
from typing import Type, Optional
from reddevil.core import RdInternalServerError
from pydantic import BaseModel

log = logging.getLogger(__name__)


class DocumentType(BaseModel):
    id: Optional[str]  # a DocuemntType is linked to a Mongodb collection


class ListType(BaseModel):
    pass


def encode_model(e: dict, validator_class: Type[DocumentType]) -> DocumentType:
    """
    validates and encodes a result dict as a validator class
    """
    try:
        eo = validator_class(**e)
    except Exception:
        log.exception(f"cannot encode model {validator_class.__name__}")
        raise RdInternalServerError(
            description=f"CannotEncode{validator_class.__name__}"
        )
    return eo
